 # coding: utf-8


import sys
import os
import re
import random
import time
#from sklearn.cluster import <any cluster algorithm>
import numpy


sekitei = None;

def define_segments(QLINK_URLS, UNKNOWN_URLS, QUOTA):
    print "define_segments is not implemented";

#
# returns True if need to fetch url
#
def fetch_url(url):
    #global sekitei
    #return sekitei.fetch_url(url);
    return True;
