
# coding: utf-8

# In[75]:

import sys
import re
import random
from operator import itemgetter


def extract_features(INPUT_FILE_1, INPUT_FILE_2, OUTPUT_FILE):
    print >> sys.stderr, "Not implemented"





