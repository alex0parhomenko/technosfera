#!/bin/bash
./broder_shingles.py "$@"